plt.show()
# *** Spyder Python Console History Log ***
Means = pd.DataFrame(np.array[[grid_lon,grid_lat,u_avg*scale_factor,v_avg*scale_factor]])
runfile(r'C:\Users\Alex\Documents\GitHub\Faga-alu-Bay-water-circulation\Code\PlotDrifters_Gridcell_Ellipses.py', wdir=r'C:\Users\Alex\Documents\GitHub\Faga-alu-Bay-water-circulation\Code')
GridMeans
GridMeans = pd.DataFrame(np.array([[grid_lon,grid_lat,u_avg*scale_factor,v_avg*scale_factor,ellipse_color]]),index=[gridcount],columns=['lon','lat','u','v','ellipse color'])
np.array([[grid_lon,grid_lat,u_avg*scale_factor,v_avg*scale_factor,ellipse_color]])
ellipse_color
np.array([[grid_lon,grid_lat,u_avg*scale_factor,v_avg*scale_factor,ellipse_color]])
runfile(r'C:\Users\Alex\Documents\GitHub\Faga-alu-Bay-water-circulation\Code\PlotDrifters_Gridcell_Ellipses.py', wdir=r'C:\Users\Alex\Documents\GitHub\Faga-alu-Bay-water-circulation\Code')
AllMeans
runfile(r'C:\Users\Alex\Documents\GitHub\Faga-alu-Bay-water-circulation\Code\PlotDrifters_Gridcell_Ellipses.py', wdir=r'C:\Users\Alex\Documents\GitHub\Faga-alu-Bay-water-circulation\Code')
Map.plot([grid_lon+Major_x1*scale_factor,grid_lon+Major_x2*scale_factor],[grid_lat+Major_y1*scale_factor,grid_lat+Major_y2*scale_factor],c=ellipse_color,norm=cNorm,lw=1)
cNorm
cNorm.vmax
cNorm.vmin
runfile(r'C:\Users\Alex\Documents\GitHub\Faga-alu-Bay-water-circulation\Code\PlotDrifters_Gridcell_Ellipses.py', wdir=r'C:\Users\Alex\Documents\GitHub\Faga-alu-Bay-water-circulation\Code')
AllMeans
runfile(r'C:\Users\Alex\Documents\GitHub\Faga-alu-Bay-water-circulation\Code\PlotDrifters_Gridcell_Ellipses.py', wdir=r'C:\Users\Alex\Documents\GitHub\Faga-alu-Bay-water-circulation\Code')
cMap,cNorm = mpl.cm.rainbow, mpl.colors.Normalize(vmin=0,vmax=200) ## =Num of observations
m = mpl.cm.ScalarMappable(norm=cNorm,cmap=cMap)
ellipse_color = m.to_rgba(NumObs)
ellipse_color
runfile(r'C:\Users\Alex\Documents\GitHub\Faga-alu-Bay-water-circulation\Code\PlotDrifters_Gridcell_Ellipses.py', wdir=r'C:\Users\Alex\Documents\GitHub\Faga-alu-Bay-water-circulation\Code')

##---(Tue Aug 12 06:57:27 2014)---
runfile(r'C:\Users\Alex\Documents\GitHub\Faga-alu-Bay-water-circulation\Code\PlotDrifters_direction_and_speed_byEndMember.py', wdir=r'C:\Users\Alex\Documents\GitHub\Faga-alu-Bay-water-circulation\Code')
AllPoints
runfile(r'C:\Users\Alex\Documents\GitHub\Faga-alu-Bay-water-circulation\Code\PlotDrifters_direction_and_speed_byEndMember.py', wdir=r'C:\Users\Alex\Documents\GitHub\Faga-alu-Bay-water-circulation\Code')
sc=Map.plot(df['lon'].values,df['lat'].values,color=df['LaunchZone'].values,latlon=True,scale=30,edgecolors='grey',linewidths=0.1,cmap='rainbow')
df=AllPoints
sc=Map.plot(df['lon'].values,df['lat'].values,color=df['LaunchZone'].values,latlon=True,scale=30,edgecolors='grey',linewidths=0.1,cmap='rainbow')
runfile(r'C:\Users\Alex\Documents\GitHub\Faga-alu-Bay-water-circulation\Code\DrifterDataAnalysisTools.py', wdir=r'C:\Users\Alex\Documents\GitHub\Faga-alu-Bay-water-circulation\Code')
runfile(r'C:\Users\Alex\Documents\GitHub\Faga-alu-Bay-water-circulation\Code\PlotDrifters_direction_and_speed_byEndMember.py', wdir=r'C:\Users\Alex\Documents\GitHub\Faga-alu-Bay-water-circulation\Code')
AllPoints
del df
del AllPoints
runfile(r'C:\Users\Alex\Documents\GitHub\Faga-alu-Bay-water-circulation\Code\DrifterDataAnalysisTools.py', wdir=r'C:\Users\Alex\Documents\GitHub\Faga-alu-Bay-water-circulation\Code')
runfile(r'C:\Users\Alex\Documents\GitHub\Faga-alu-Bay-water-circulation\Code\PlotDrifters_direction_and_speed_byEndMember.py', wdir=r'C:\Users\Alex\Documents\GitHub\Faga-alu-Bay-water-circulation\Code')
sc = Map.scatter(AllPoints['lon'],AllPoints['lat'],latlon=True,c=AllPoints['LaunchZone'],cmap=plt.get_cmap('rainbow'))
runfile(r'C:\Users\Alex\Documents\GitHub\Faga-alu-Bay-water-circulation\Code\PlotDrifters_direction_and_speed_byEndMember.py', wdir=r'C:\Users\Alex\Documents\GitHub\Faga-alu-Bay-water-circulation\Code')
Map.scatter(df['lon'].values,df['lat'].values,latlon=True,c=df['LaunchZone'].values,cmap=plt.get_cmap('rainbow'),edgecolor='None') 
df=AllPoints
Map.scatter(df['lon'].values,df['lat'].values,latlon=True,c=df['LaunchZone'].values,cmap=plt.get_cmap('rainbow'),edgecolor='None') 
runfile(r'C:\Users\Alex\Documents\GitHub\Faga-alu-Bay-water-circulation\Code\PlotDrifters_direction_and_speed_byEndMember.py', wdir=r'C:\Users\Alex\Documents\GitHub\Faga-alu-Bay-water-circulation\Code')
GridResTime = 100/GridMean_speed/60
runfile(r'C:\Users\Alex\Documents\GitHub\Faga-alu-Bay-water-circulation\Code\PlotDrifters_Gridcell_ResidenceTime.py', wdir=r'C:\Users\Alex\Documents\GitHub\Faga-alu-Bay-water-circulation\Code')
shape
shape.parts
plt.plot(shape.parts)
shape.points
runfile(r'C:\Users\Alex\Documents\GitHub\Faga-alu-Bay-water-circulation\Code\PlotDrifters_Gridcell_ResidenceTime.py', wdir=r'C:\Users\Alex\Documents\GitHub\Faga-alu-Bay-water-circulation\Code')
runfile(r'C:\Users\Alex\Documents\GitHub\Faga-alu-Bay-water-circulation\Code\DrifterDataAnalysisTools.py', wdir=r'C:\Users\Alex\Documents\GitHub\Faga-alu-Bay-water-circulation\Code')
ResTime_color
plt.gca().add_patch(poly)
poly = Polygon(Map(shape.points),facecolor=ResTime_color)
Map(shape.points)
shape.points
Map.grid100m_geo
Map.grid100m_geo_info
Map(shape.points)
Map(Map.grid100m_geo.points)
grid.shapes
grid.shape
plt.add_patch(poly)
shape.points
verts = shape.points
path=Path(verts)
poly = Polygon(path,facecolor=ResTime_color)
plt.gca().add_patch(poly)
from matplotlib.path    import Path
verts = shape.points
path=Path(verts)
poly = Polygon(path,facecolor=ResTime_color)
plt.gca().add_patch(poly)
path
runfile(r'C:\Users\Alex\Documents\GitHub\Faga-alu-Bay-water-circulation\Code\PlotDrifters_Gridcell_ResidenceTime.py', wdir=r'C:\Users\Alex\Documents\GitHub\Faga-alu-Bay-water-circulation\Code')
path
path[:,1]
shape.points
np.array(shape.points))
np.array(shape.points)
pts = np.array(shape.points)
Map(pts)
pts.T
pts = np.array(shape.points).T
pts
verts = np.array(shape.points).T
verts[0]
Map(verts[0],verts[1])
Map(np.array(shape.points).T)
verts = Map(np.array(shape.points).T)
np.array(shape.points).T
verts = np.array(shape.points).T
poly_lons,poly_lats=Map(verts[0],verts[1])
poly_lons
zip(poly_lons,poly_lats)
poly_lats
runfile(r'C:\Users\Alex\Documents\GitHub\Faga-alu-Bay-water-circulation\Code\PlotDrifters_Gridcell_ResidenceTime.py', wdir=r'C:\Users\Alex\Documents\GitHub\Faga-alu-Bay-water-circulation\Code')
runfile(r'C:\Users\Alex\Documents\GitHub\Faga-alu-Bay-water-circulation\Code\PlotDrifters_Gridcell_Ellipses.py', wdir=r'C:\Users\Alex\Documents\GitHub\Faga-alu-Bay-water-circulation\Code')
runfile(r'C:\Users\Alex\Documents\GitHub\Faga-alu-Bay-water-circulation\Code\DrifterDataAnalysisTools.py', wdir=r'C:\Users\Alex\Documents\GitHub\Faga-alu-Bay-water-circulation\Code')
runfile(r'C:\Users\Alex\Documents\GitHub\Faga-alu-Bay-water-circulation\Code\PlotDrifters_Gridcell_mean_direction_and_speed.py', wdir=r'C:\Users\Alex\Documents\GitHub\Faga-alu-Bay-water-circulation\Code')